/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gametest;

/**
 *
 * @author Tyler
 */
import java.awt.*;
import java.util.*;
/**
 * Food is a food item that the snake can eat. It is placed randomly in the pit.
 */
public class Food {
   
   private int x, y;   // current food location (x, y) in cells
   private Color color = Color.BLUE;   // color for display
   private Random rand = new Random(); // For randomly placing the food
   
   // Default constructor.
   public Food() {
      // place outside the pit, so that it will not be "displayed".
      x = -1;
      y = -1;
   }
   
   // Regenerate a food item. Randomly place inside the pit (slightly off the edge).
   public void regenerate() {
      x = rand.nextInt(GameTest.COLUMNS - 4) + 2;
      y = rand.nextInt(GameTest.ROWS - 4) + 2;
   }
   
   // Returns the x coordinate of the cell that contains this food item.
   public int getX() { return x; }
   
   // Returns the y coordinate of the cell that contains this food item.
   public int getY() { return y; }
   
   // Draw itself.
   public void draw(Graphics g) {
      g.setColor(color);
      g.fill3DRect(x * GameTest.CELL_SIZE, y * GameTest.CELL_SIZE,
            GameTest.CELL_SIZE, GameTest.CELL_SIZE, true);
   }
}
