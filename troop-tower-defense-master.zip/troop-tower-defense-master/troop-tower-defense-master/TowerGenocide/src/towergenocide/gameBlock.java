/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package towergenocide;

import java.awt.*;
/**
 *
 * @author Tyler
 */
public class gameBlock extends Rectangle{
    public int groundID;
    public int airID;
    
    public gameBlock(int x, int y, int width, int height, int groundID, int airID){
        setBounds(x, y, width, height);
        this.groundID = groundID;
        this.airID = airID;
        
        
    }
    
    public void draw(Graphics g) {
        if(groundID == Value.groundGrass){
            g.drawImage(gameScreen.tileset_sky[groundID], x, y, width, height,null);
        }
        else if(groundID == Value.groundRoad){
         
            g.drawImage(gameScreen.tileset_road[groundID],x, y, width, height, null);
         
            
        }
        if(airID != Value.airAir){
             //g.drawImage(gameScreen.tileset_ground[airID], x, y, width, height, null);
            
        }
        
    }
}
