/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package towergenocide;


import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;


/**
 *
 * @author Tyler
 */
public class gameScreen extends JPanel implements Runnable {
    
   public Thread thread = new Thread(this);
   
   public static Image[] tileset_sky = new Image[100];
  // public static Image[] tileset_air = new Image[100];
   public static Image[] tileset_road = new Image[100];
   public static Image[] tileset_troops = new Image[100];
   public static Image[] tileset_enemy = new Image[100];
   
   public static int myWidth, myHeight;
   public static int money =10, health = 100;
   
   
   public static boolean isFirst = true;
   
   
   public static Point mse = new Point(0,0);
   
   public static gameRoom room;
   public static Save save;
   //public static Store store;
   
   public static Enemy[] enemies = new Enemy[100];
   public static Troops[] troops = new Troops[100];
   
    public gameScreen(GameWindow game) {
        
        
        thread.start();
        
    }
    
    public void define() {
        room = new gameRoom();
        save = new Save();
        //store = new Store();
        
      
        
        for(int i=0; i < tileset_sky.length; i++){
            tileset_sky[i] = new ImageIcon("E:\\troop-tower-defense-master\\troop-tower-defense-master\\TowerGenocide\\src\\towergenocide\\skytile.png").getImage();
            tileset_sky[i] = createImage(new FilteredImageSource(tileset_sky[i].getSource(), new CropImageFilter(0, 26*i, 26, 26)));
             
        }
        /*
         for(int i=0; i < tileset_air.length; i++){
            tileset_air[i] = new ImageIcon("E:\\testGame\\tdTest\\src\\res\\tileset_air.png").getImage();
            tileset_air[i] = createImage(new FilteredImageSource(tileset_air[i].getSource(), new CropImageFilter(0, 26*i, 26, 26)));
         */   
        //}
          for(int i=0; i < tileset_road.length; i++){
            tileset_road[i] = new ImageIcon("E:\\troop-tower-defense-master\\troop-tower-defense-master\\TowerGenocide\\src\\towergenocide\\skytile.png").getImage();
            tileset_road[i] = createImage(new FilteredImageSource(tileset_road[i].getSource(), new CropImageFilter(0, 26*i, 26, 26)));
            
        }
          
         // tileset_res[0] = new ImageIcon("E:\\testGame\\tdTest\\src\\res\\cell.png").getImage(); 
         // tileset_res[1] = new ImageIcon("E:\\testGame\\tdTest\\src\\res\\health.png").getImage();
         // tileset_res[2] = new ImageIcon("E:\\testGame\\tdTest\\src\\res\\coins.png").getImage();
          tileset_enemy[0] = new ImageIcon("E:\\troop-tower-defense-master\\enemyWalk.gif").getImage();
          tileset_troops[0] = new ImageIcon("E:\\troop-tower-defense-master\\troopWalk.gif").getImage();
          
          
         try {
            save.loadSave(new File("E:\\troop-tower-defense-master\\troop-tower-defense-master\\TowerGenocide\\src\\towergenocide\\map.level"));
         }
         catch(Exception e){
             e.printStackTrace();
         }
         
          for(int i=0; i<enemies.length; i++){
            enemies[i] = new Enemy();
            
            
        }
          for (int i=0; i <troops.length; i++){
              troops[i] = new Troops();
          }
         
         
    }
    
   @Override
    public void paintComponent(Graphics g){
        
        if(isFirst){
            myWidth = getWidth();
            myHeight = getHeight();
            
            define();
            isFirst = false;
        }
        
        g.setColor(new Color(30,100,30));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(new Color(0,0,230)); 
        //drawing the left line border
        g.drawLine(room.block[0][0].x-1, 0, room.block[0][0].x-1, room.block[room.worldHeight-1][0].y +room.blockSize); 
        //drawing the right line border
        g.drawLine(room.block[0][room.worldWidth-1].x +room.blockSize, 0, room.block[0][room.worldWidth-1].x + room.blockSize, room.block[room.worldHeight-1][0].y +room.blockSize );
        // draw botton line border
        g.drawLine(room.block[0][0].x, room.block[room.worldHeight-1][0].y +room.blockSize,room.block[0][room.worldWidth-1].x +room.blockSize , room.block[room.worldHeight-1][0].y +room.blockSize);
      
        
        room.draw(g); //draw the room
        
        
        for (int i=0; i <enemies.length; i++){
            if(enemies[i].inGame){
                enemies[i].draw(g);
            }
            
            
        }
         for (int i=0; i <troops.length; i++){
            if(troops[i].inGame){
                troops[i].draw(g);
            }
         }
        
       // store.draw(g); // draw the store
        
    }
    
    
    public int spawnTime = 2400, spawnFrame =0;
    public void enemySpawner(){
        if(spawnFrame >= spawnTime){
            for (int i=0; i < enemies.length; i++){
                if(!enemies[i].inGame){
                    enemies[i].spawnEnemy(Value.enemyGreen);
                    
                    break;
                }
                
            }
            
            spawnFrame =0; 
        }
        else {
            spawnFrame +=1;
        }
        
    }
     public void troopSpawner(){
        if(spawnFrame >= spawnTime){
            for (int i=0; i < troops.length; i++){
                if(!troops[i].inGame){
                    troops[i].spawnTroops(Value.enemyGreen);
                    
                    break;
                }
                
            }
            
            spawnFrame =0; 
        }
        else {
            spawnFrame +=1;
        }
        
    }
    
    
   @Override
    public void run (){
        while(true){
            if(!isFirst){
                room.physic();
                enemySpawner();
                for(int i=0; i < enemies.length;i++){
                    enemies[i].physic();
                }
                troopSpawner();
                for (int i=0; i<troops.length; i++){
                    troops[i].physic();
                }
            }
            repaint();
            
            try {
                Thread.sleep(1);
            }
            catch (Exception e) {
                
            }
        }
        
    }
    
}