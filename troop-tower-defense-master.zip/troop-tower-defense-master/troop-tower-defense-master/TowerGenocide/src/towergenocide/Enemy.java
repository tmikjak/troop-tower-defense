/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package towergenocide;

import java.awt.*;
/**
 *
 * @author Tyler
 */
public class Enemy extends Rectangle{
    public int enemySize = 52;
    public int enemyID = Value.enemyAir; 
    public boolean inGame = false;
    public int xC, yC;
    public int enemyWalk = 0;
    public int left=2;
    public int direction = left;
   
            
   
    //int x = 900;
    
    
    public Enemy(){
       
        
    }
    
    public void spawnEnemy(int enemyID){
         for (int y=0; y <gameScreen.room.block.length; y++){
             if(gameScreen.room.block[y][0].groundID == Value.groundRoad){
                 setBounds(gameScreen.room.block[y][0].x, gameScreen.room.block[y][0].y, enemySize, enemySize);
                 xC = x = 900;
                 yC =0;
             }
            
        }
         
         this.enemyID = enemyID;
         inGame = true;
    }
    
    public int walkFrame =0, walkSpeed= 40;
    public void physic(){
        if(walkFrame >= walkSpeed){
            if(direction == left){
                x -= 1;
            }
    
            enemyWalk += 1;
            
            if(enemyWalk == gameScreen.room.blockSize){
                if(direction == left){
                     xC -= 1;
                     
                }
           
                enemyWalk=0;
                
                
            }
            
            walkFrame =0;
        } else {
            walkFrame += 1;
        }
    }
    
         
         public void draw(Graphics g){
             if(inGame){
                 g.drawImage(gameScreen.tileset_enemy[enemyID], x, y, width, height, null);
                 
             }
              
         }
        
    
            
            
            
}