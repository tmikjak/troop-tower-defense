/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package towergenocide;

/**
 *
 * @author Tyler
 */
import java.awt.*;
/**
 *
 * @author Tyler
 */
public class Troops extends Rectangle{
    public int enemySize = 52;
    public int enemyID = Value.enemyAir; 
    public boolean inGame = false;
    public int xC, yC;
    public int enemyWalk = 0;
    public int right=2;
    public int direction = right;
   
           
    
    
    public Troops(){
       
        
    }
    
    public void spawnTroops(int enemyID){
         for (int y=0; y <gameScreen.room.block.length; y++){
             if(gameScreen.room.block[y][0].groundID == Value.groundRoad){
                 setBounds(gameScreen.room.block[y][0].x, gameScreen.room.block[y][0].y, enemySize, enemySize);
                 xC = 0;
                 yC = y;
             }
            
        }
         
         this.enemyID = enemyID;
         inGame = true;
    }
    
    public int walkFrame =0, walkSpeed= 40;
    public void physic(){
        if(walkFrame >= walkSpeed){
            if(direction == right){
                x += 1;
            }
    
            enemyWalk += 1;
            
            if(enemyWalk == gameScreen.room.blockSize){
                if(direction == right){
                     xC += 1;
                     
                }
           
                enemyWalk=0;
                
                
            }
            
            walkFrame =0;
        } else {
            walkFrame += 1;
        }
    }
    
         
         public void draw(Graphics g){
             if(inGame){
                 g.drawImage(gameScreen.tileset_troops[enemyID], x, y, width, height, null);
                 
             }
              
         }
        
    
            
            
            
}
