/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package towergenocide;

/**
 *
 * @author Tyler
 */
public class Value {
    public static int groundGrass = 0;
    public static int groundRoad = 1;
    public static int airAir = -1; 
    public static int enemyAir = -1;
    public static int enemyGreen = 0;
}
